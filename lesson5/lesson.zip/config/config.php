<?php
//   пути к папкам проекта
define("ROOT", dirname(__DIR__));
define ('TEMPLATES_DIR', ROOT . '/templates/');
define ('LAYOUTS_DIR', 'layouts/');
define ("IMG_SMALL", $_SERVER['DOCUMENT_ROOT'] . "/img/small/");
//    настройки базы данных
define('HOST', 'localhost');
define('USER', 'student');
define('PASS', '123456');
define('DB', 'gb');
//    подключаем файлы движка сайта
include ROOT . "/engine/functions.php";
include ROOT . "/engine/db.php";
include ROOT . "/engine/catalog.php";