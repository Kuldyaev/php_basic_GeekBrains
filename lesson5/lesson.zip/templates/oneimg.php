<br/>
<img src="<?=$img['way']?>" alt="Valegio Image" class="oneImg">
<div>
    Views: <?=$img['views']?>
</div>
