<a href="/">Главная</a>
<a href="/catalog">Галерея</a>